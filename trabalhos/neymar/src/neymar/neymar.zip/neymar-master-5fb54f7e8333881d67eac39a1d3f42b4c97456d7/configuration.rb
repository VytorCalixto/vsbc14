class Configuration

  BUF_SIZE = 142
  PORT = 1337
  ANSWER_BUF_SIZE = 1024*10
  ANSWER_PORT = 1338

end
