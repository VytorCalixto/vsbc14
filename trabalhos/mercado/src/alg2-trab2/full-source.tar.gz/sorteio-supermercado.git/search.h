#ifndef SEARCH_H
#define SEARCH_H
int pesqSeq(int vetor[], int valor, int tamVetor, int *nComp);
int pesqBin(int vetor[], int valor, int esq, int dir, int *nComp);
#endif
