#ifndef SORT_H
#define SORT_H
void mergeSort(int vetor[], int vetAux[], int esq, int dir, int *nComp);
void quickSort(int vetor[], int esq, int dir, int tipoParticao, int *nComp);
#endif
